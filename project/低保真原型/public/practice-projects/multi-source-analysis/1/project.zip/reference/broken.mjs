export const solve=()=>[{"id":"A1","channel":"web","ordered":24000,"paid":12000},{"id":"A2","channel":"community","ordered":8000,"paid":8000},{"id":"A3","channel":"web","ordered":6000,"paid":0}];
