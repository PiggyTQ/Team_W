# Reproducible defect evidence

Reference executions are author reproductions. Uploads remain user-reported local execution.
