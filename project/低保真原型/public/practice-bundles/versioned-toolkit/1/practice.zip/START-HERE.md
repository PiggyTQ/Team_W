# Versioned maintainable toolkit

Use the extracted files in this directory. Read assignment.md (or assignment.en.md), input/dictionary.md and RUN.md.

Node 24; no package installation, paid model or external cloud is required.

- Public reference: `node verify.mjs --reference`.
- Implement your source and run `node verify.mjs`.
- SQL: `node run-sql.mjs --reference`, then edit query.sql and run `node run-sql.mjs`.
- Configuration: edit rules.json and run `node instance-runner-1.mjs base` using the supplied evaluator. `--reference` reproduces the public configuration.
- Variants: use the selected ID with `node instance-runner-1.mjs data-1 --reference --sql`, `api-1 --reference --http`, or `rules-1 --reference`. Remove `--reference` to check your source/configuration.

The included project.zip is a retained archive material file. Work with this directory's already extracted files. DELIVERY.json identifies this complete delivery envelope.

本目录为完整解压工作目录。先读任务书、字段说明和运行步骤。参考复现为 `node verify.mjs --reference`；修订自己的程序后执行 `node verify.mjs`。规则项目可使用配套运行器核对自己编辑的 rules.json，无需重写评价器。变式使用本次选择的实例ID。project.zip 是保留的归档材料，请直接使用已经解压出的文件。本机执行、文件核对和本人复核均不等同独立能力证明。
