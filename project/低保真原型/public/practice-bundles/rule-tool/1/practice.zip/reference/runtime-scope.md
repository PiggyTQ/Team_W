# Rule and conversion tool

Reference executions are author reproductions. Uploads remain user-reported local execution.
